/******************************************************************************
 * Author:      Thomas Sweet
 * Date:        04/05/2025
 * Description: Corner Grocer Item Tracker
 *              This program reads a text file listing items purchased during
 *              the day, counts the frequency of each item using a map, and
 *              then offers a menu to:
 *                 1. Search for a specific item's frequency
 *                 2. Display all items and their frequencies
 *                 3. Display a histogram of item frequencies
 *                 4. Exit the program
 *
 *              The program also writes a backup file (frequency.dat) that
 *              contains all items with their frequency counts.
 ******************************************************************************/

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>
using namespace std;

// Class to encapsulate item tracking functionality
class ItemTracker {
private:
    // Map to store each item and its frequency
    map<string, int> frequencyData;

public:
    // Constructor
    ItemTracker() {}

    // Loads data from the input file and counts item frequencies.
    // Returns true if successful, false otherwise.
    bool loadData(const string &filename) {
        ifstream inputFile(filename);
        if (!inputFile) {
            cerr << "Error: Unable to open input file " << filename << endl;
            return false;
        }
        string item;
        // Read each word (assumed to be an item) from the file
        while (inputFile >> item) {
            frequencyData[item]++;
        }
        inputFile.close();
        return true;
    }

    // Searches for a specific item's frequency.
    // Returns the count (0 if not found).
    int searchItem(const string &item) const {
        auto it = frequencyData.find(item);
        if (it != frequencyData.end()) {
            return it->second;
        }
        return 0;
    }

    // Displays all items and their frequencies in a formatted table.
    void displayAllFrequencies() const {
        cout << "\nItem Frequency List:" << endl;
        cout << "----------------------------------" << endl;
        cout << left << setw(20) << "Item" << "Frequency" << endl;
        cout << "----------------------------------" << endl;
        for (const auto &entry : frequencyData) {
            cout << left << setw(20) << entry.first << entry.second << endl;
        }
        cout << "----------------------------------" << endl;
    }

    // Displays a histogram where each item is followed by a number of asterisks
    // equal to its frequency.
    void displayHistogram() const {
        cout << "\nHistogram:" << endl;
        cout << "----------------------------------" << endl;
        for (const auto &entry : frequencyData) {
            cout << left << setw(20) << entry.first;
            for (int i = 0; i < entry.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
        cout << "----------------------------------" << endl;
    }

    // Writes the frequency data to a backup file.
    // Returns true if successful, false otherwise.
    bool writeBackupFile(const string &backupFilename) const {
        ofstream outFile(backupFilename);
        if (!outFile) {
            cerr << "Error: Unable to open output file " << backupFilename << endl;
            return false;
        }
        for (const auto &entry : frequencyData) {
            outFile << entry.first << " " << entry.second << endl;
        }
        outFile.close();
        return true;
    }
};

// Displays the main menu options.
void displayMenu() {
    cout << "\nCorner Grocer Item Tracker Menu:" << endl;
    cout << "1. Search for a specific item's frequency" << endl;
    cout << "2. Display all items and their frequencies" << endl;
    cout << "3. Display histogram of item frequencies" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter your choice: ";
}

int main() {
    // Create an ItemTracker object.
    ItemTracker tracker;
    string inputFilename = "CS210_Project_Three_Input_File.txt";

    // Load data from the input file.
    if (!tracker.loadData(inputFilename)) {
        cout << "Exiting program due to input file error." << endl;
        return 1;
    }

    // Write backup file (frequency.dat) immediately after loading data.
    string backupFilename = "frequency.dat";
    if (!tracker.writeBackupFile(backupFilename)) {
        cout << "Warning: Backup file could not be created." << endl;
    } else {
        cout << "Backup file '" << backupFilename << "' created successfully." << endl;
    }

    int choice = 0;
    while (true) {
        displayMenu();
        cin >> choice;

        // Input validation: check if the user entered an integer.
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please enter a number between 1 and 4." << endl;
            continue;
        }

        // Process menu options.
        if (choice == 1) {
            // Option 1: Search for a specific item.
            cout << "Enter the item name to search for: ";
            string searchItem;
            cin >> searchItem;
            int freq = tracker.searchItem(searchItem);
            cout << "The item '" << searchItem << "' appears " << freq << " times." << endl;
        } else if (choice == 2) {
            // Option 2: Display the frequency list for all items.
            tracker.displayAllFrequencies();
        } else if (choice == 3) {
            // Option 3: Display a histogram of item frequencies.
            tracker.displayHistogram();
        } else if (choice == 4) {
            // Option 4: Exit the program.
            cout << "Exiting program. Goodbye!" << endl;
            break;
        } else {
            cout << "Invalid choice. Please select a valid menu option." << endl;
        }
    }

    return 0;
}
